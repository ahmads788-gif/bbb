
    window.addEventListener('DOMContentLoaded', () => {
        if (window.location.search.startsWith('?login')) {
            $('#login_modal').modal();
            $('#popup_modal').modal('hide');
        }
    });
