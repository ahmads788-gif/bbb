
        window.addEventListener('DOMContentLoaded', () => {
            initializeCurrency({
                conversionRate: 1000,
                thousandSeparator: ".",
                locale: "id"
            });
        });
    