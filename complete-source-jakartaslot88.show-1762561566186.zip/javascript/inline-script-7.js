
        window.addEventListener('DOMContentLoaded', () => {
            initializeCopyAccountNumber({
                translations: {
                    copied: "Disalin"
                }
            });
        });
    