
    window.addEventListener('DOMContentLoaded', () => {
        if (window.location.search.startsWith('?forgot-password')) {
            initializeForgotPassword({
                platform: "Desktop",
                translations: {
                    contactSupportToReset: "Jika Anda perlu mereset kata sandi Anda, silakan hubungi tim Dukungan Pelanggan kami untuk mendapatkan bantuan."
                }
            });
            $('#forgot_password_modal').modal();
            $('#popup_modal').modal('hide');
        }
    });
