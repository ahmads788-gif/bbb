
            window.addEventListener('DOMContentLoaded', () => {
                const template = document.querySelector('#live_chat_template');

                document.body.append(template.content.cloneNode(true));
            });
        