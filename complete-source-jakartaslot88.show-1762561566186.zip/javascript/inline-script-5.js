
            window.addEventListener('DOMContentLoaded', () => {
                if (window.location.search.startsWith('?register')) {
                    $('#register_modal').modal();
                    $('#popup_modal').modal('hide');
                }
            });
        