
    window.addEventListener('DOMContentLoaded', () => {
        const passwordInputTrigger = document.querySelector('#password_input_trigger');
        const passwordInput = document.querySelector('#password_input');

        passwordInputTrigger.onclick = () => {
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';

                return;
            }

            passwordInput.type = 'password';
        };
    });
