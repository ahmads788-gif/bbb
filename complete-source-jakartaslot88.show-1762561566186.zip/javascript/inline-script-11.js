
            window.addEventListener('DOMContentLoaded', () => {
                initializeForgotPassword({
                    platform: "Desktop",
                    translations: {
                        contactSupportToReset: "Jika Anda perlu mereset kata sandi Anda, silakan hubungi tim Dukungan Pelanggan kami untuk mendapatkan bantuan."
                    }
                });
            });
        