Source Code Extraction Report
=============================

Domain: jakartaslot88.show
Total Files: 53
Total Images: 29
Total Size: 5.74 MB

Language Breakdown:
- html: 1 files
- css: 7 files
- text: 1 files
- javascript: 15 files

Image Files: 29

Extracted on: 2025-11-08T00:26:05.424Z
